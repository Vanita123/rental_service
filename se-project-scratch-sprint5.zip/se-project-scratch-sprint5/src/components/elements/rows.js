import styled from "styled-components";

const Row = styled.div`
    width: 90%;
    margin-bottom: 5px;
    margin-top: 5px;
`;

export default Row;